public partial class Program { }
